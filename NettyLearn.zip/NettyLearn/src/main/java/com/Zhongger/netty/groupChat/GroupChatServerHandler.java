package com.Zhongger.netty.groupChat;

import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.group.ChannelGroup;
import io.netty.channel.group.DefaultChannelGroup;
import io.netty.util.concurrent.GlobalEventExecutor;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author zhongmingyi
 * @date 2021/10/8 10:31 下午
 */
public class GroupChatServerHandler extends SimpleChannelInboundHandler<String> {
    //定义一个Channel组，管理所有的Channel
    //GlobalEventExecutor.INSTANCE表示全局的事件执行器，单例的
    private static ChannelGroup channelGroup = new DefaultChannelGroup(GlobalEventExecutor.INSTANCE);
    private SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    //表示Channel处于活动状态，提示上线
    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        System.out.println("[客户端]" + ctx.channel().remoteAddress() + simpleDateFormat.format(new Date()) + "上线了");
    }

    //表示Channel处于非活动状态，提示下线
    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        System.out.println("[客户端]" + ctx.channel().remoteAddress() + simpleDateFormat.format(new Date()) + "离线了");
    }

    //handlerAdded表示连接建立，一旦连接，该方法第一个被执行，将当前Channel加入到当前ChannelGroup中
    @Override
    public void handlerAdded(ChannelHandlerContext ctx) throws Exception {
        channelGroup.add(ctx.channel());
        //将加入聊天的信息推送给其他在线的客户端
        channelGroup.writeAndFlush("[客户端]" + ctx.channel().remoteAddress() + simpleDateFormat.format(new Date()) + "加入了聊天");
    }

    //handlerRemoved表示断开连接，会被触发
    @Override
    public void handlerRemoved(ChannelHandlerContext ctx) throws Exception {
        channelGroup.writeAndFlush("[客户端]" + ctx.channel().remoteAddress() + simpleDateFormat.format(new Date()) + "离开了聊天");
    }

    //读取数据
    @Override
    protected void channelRead0(ChannelHandlerContext channelHandlerContext, String s) throws Exception {
        Channel channel = channelHandlerContext.channel();
        channelGroup.forEach(ch -> {
            if (ch != channel) {
                //不是当前的Channel
                ch.writeAndFlush("[客户端]" + channel.remoteAddress() + simpleDateFormat.format(new Date()) + "发送消息：" + s + "\n");
            } else {
                ch.writeAndFlush("[自己]" + channel.remoteAddress() + simpleDateFormat.format(new Date()) + "发送消息" + s + " 给自己\n");
            }
        });
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        ctx.close();
    }
}
