package com.Zhongger.protocoltcp;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

/**
 * @author zhongmingyi
 * @date 2021/10/20 9:45 下午
 */
public class MyServerHandler extends SimpleChannelInboundHandler<MessageProtocol> {
    private int count;

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        cause.printStackTrace();
        ctx.close();
    }

    @Override
    protected void channelRead0(ChannelHandlerContext channelHandlerContext, MessageProtocol messageProtocol) throws Exception {
        int len = messageProtocol.getLen();
        byte[] content = messageProtocol.getContent();
        System.out.println("服务端接收到信息如下：");
        System.out.println("长度：" + len);
        System.out.println("内容：" + new String(content, StandardCharsets.UTF_8));
        System.out.println("服务器接收到消息包数量：" + (++this.count));

        String responseContent = UUID.randomUUID().toString();
        int length = responseContent.getBytes(StandardCharsets.UTF_8).length;
        MessageProtocol messageProtocol1 = new MessageProtocol();
        messageProtocol1.setContent(responseContent.getBytes());
        messageProtocol1.setLen(length);
        channelHandlerContext.writeAndFlush(messageProtocol1);
    }
}
