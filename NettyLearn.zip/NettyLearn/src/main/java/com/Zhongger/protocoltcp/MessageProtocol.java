package com.Zhongger.protocoltcp;

/**
 * @author zhongmingyi 协议包
 * @date 2021/10/23 11:29 上午
 */
public class MessageProtocol {
    private int len;
    private byte[] content;

    public int getLen() {
        return len;
    }

    public void setLen(int len) {
        this.len = len;
    }

    public byte[] getContent() {
        return content;
    }

    public void setContent(byte[] content) {
        this.content = content;
    }
}
